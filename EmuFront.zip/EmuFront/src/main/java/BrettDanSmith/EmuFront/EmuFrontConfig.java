package BrettDanSmith.EmuFront;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class EmuFrontConfig {

	private String fileLocation;
	private File configFile;
	private FileInputStream inputStream;
	private FileOutputStream outputStream;
	private Properties properties;

	public EmuFrontConfig(String fileLocation, String[] args) {
		this.fileLocation = fileLocation;
		this.configFile = new File(fileLocation);
	}

	public void load() {
		Logger.info("Loading EmuFront configuration file...");
		try {
			inputStream = new FileInputStream(configFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		properties = new Properties();
		try {
			properties.load(inputStream);
			inputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		Logger.info("Loaded EmuFront configuration file!");
	}

	public void save(boolean first) {
		Logger.info("Saving EmuFront configuration file...");
		try {
			outputStream = new FileOutputStream(configFile);
			properties.store(outputStream, "EmuFront configuration file v0.0.1");
			outputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		Logger.info("Saved EmuFront configuration file!");
	}

	public String getString(String key) {
		return properties.getProperty(key);
	}

	public String setString(String key, String value) {
		properties.setProperty(key, value);
		return value;
	}

}
