package BrettDanSmith.EmuFront;

import javax.swing.UIManager;

import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;

public class EmuFrontCore {

	private static EmuFrontCore INSTANCE;
	private EmuFrontConfig config;
	public ConsoleLoader consoleLoader;

	public EmuFrontCore(EmuFrontConfig config) {
		INSTANCE = this;
		this.config = config;
	}

	public static void preInit(String[] args) {
		Logger.info("Pre-Initialising EmuFront...");
		Thread shutdownHook = new Thread(() -> shutdown());
		Runtime.getRuntime().addShutdownHook(shutdownHook);
	}

	public void initialise() {
		Logger.info("Initialising EmuFront...");
		try {
			UIManager.setLookAndFeel(
					config.getString("window_theme").equals("light") ? new FlatLightLaf() : new FlatDarkLaf());
		} catch (Exception ex) {
			Logger.error(ex);
		}
		
		consoleLoader = new ConsoleLoader();
		consoleLoader.search();
	}

	public EmuFrontConfig getConfig() {
		return config;
	}

	public static void shutdown() {
		Logger.info("STOPPING EmuFront...");
		INSTANCE.config.save(false);
	}

	public static EmuFrontCore getINSTANCE() {
		return INSTANCE;
	}

}
