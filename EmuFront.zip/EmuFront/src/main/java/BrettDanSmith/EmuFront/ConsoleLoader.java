package BrettDanSmith.EmuFront;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class ConsoleLoader {
	private File consolesDirectory;

	public List<ConsoleData> consoles = new ArrayList<ConsoleData>();

	public ConsoleLoader() {
		consolesDirectory = new File("data/consoles/");
	}

	public void search() {
		Logger.info("Searching for consoles...");

		for (File subFile : consolesDirectory.listFiles()) {
			if (!subFile.isDirectory())
				continue;

			File consoleFile = new File(subFile, "console.cfg");
			if (!consoleFile.exists())
				continue;

			ConsoleData console = parseConsoleFile(consoleFile);
			console.consoleFile = consoleFile;
			console.consoleDirectory = subFile;
			consoles.add(console);

			Logger.info("Loaded " + console.consoleTitle);

		}

		Logger.info("Loaded " + consoles.size() + " consoles.");

	}

	public ConsoleData parseConsoleFile(File consoleFile) {
		ConsoleData consoleData = new ConsoleData();
		FileInputStream inputStream;
		Properties properties = null;
		try {
			inputStream = new FileInputStream(consoleFile);
			properties = new Properties();
			properties.load(inputStream);
			inputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		consoleData.consoleTitle = properties.getProperty("console_title", "CONSOLE NAME");
		consoleData.consoleIcon = properties.getProperty("console_icon", "icon.png");
		consoleData.starting_args = properties.getProperty("starting_args");

		return consoleData;
	}

}
