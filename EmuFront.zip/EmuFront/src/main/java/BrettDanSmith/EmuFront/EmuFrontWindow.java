package BrettDanSmith.EmuFront;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.SpringLayout;

public class EmuFrontWindow extends JFrame {
	private static final long serialVersionUID = 5839214671497183366L;
	private JPanel contentPane;
	private EmuFrontConfig config;
	private EmuFrontCore core;

	/**
	 * Create the frame.
	 * 
	 * @param core
	 * @param config
	 */
	public EmuFrontWindow(EmuFrontConfig config, EmuFrontCore core) {
		this.config = config;
		this.core = core;
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					setResizable(false);
					setPreferredSize(new Dimension(1280, 720));
					setSize(new Dimension(1280, 720));
					setLocationRelativeTo(null);
					setTitle("EmuFront  |  v0.0.1-SNAPSHOT");
					contentPane = new JPanel();

					setContentPane(contentPane);
					contentPane.setLayout(new BorderLayout(0, 0));

					JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.LEFT);
					tabbedPane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
					contentPane.add(tabbedPane, BorderLayout.CENTER);

					JPanel panelOverview = new JPanel();
					tabbedPane.addTab("Overview", null, panelOverview, null);
					panelOverview.setLayout(new BorderLayout(0, 0));

					JScrollPane scrollPane = new JScrollPane();
					scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
					scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
					scrollPane.getVerticalScrollBar().setUnitIncrement(16);
					panelOverview.add(scrollPane, BorderLayout.CENTER);

					JPanel panel = new JPanel();
					scrollPane.setViewportView(panel);
					panel.setLayout(new WrapLayout(FlowLayout.CENTER, 32, 32));

					for (ConsoleData data : core.consoleLoader.consoles) {
						panel.add(new EmulatorEntryPanel(data));
					}

					JPanel panelConfiguration = new JPanel();
					tabbedPane.addTab("Configuration", null, panelConfiguration, null);
					panelConfiguration.setLayout(new SpringLayout());

					JPanel panelAbout = new JPanel();
					tabbedPane.addTab("About", null, panelAbout, null);
					panelAbout.setLayout(new SpringLayout());

				} catch (Exception e) {
					Logger.error(e);
				}
			}
		});
	}

	public void showWindow() {
		this.setVisible(true);
	}

	public EmuFrontConfig getConfig() {
		return config;
	}

	public EmuFrontCore getCore() {
		return core;
	}

}
