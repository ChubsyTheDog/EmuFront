package BrettDanSmith.EmuFront;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Logger {

	private static String getTimeDate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd-HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		return dtf.format(now);
	}

	public static void info(Object o) {
		System.out.println("[" + getTimeDate() + "][INFO]: " + o);
	}

	public static void debug(Object o) {
		System.out.println("[" + getTimeDate() + "][DEBUG]: " + o);
	}

	public static void error(Object o) {
		String string = "[" + getTimeDate() + "][ERROR]: " + o;
		System.out.println(string);
		System.err.println(string);
	}

}
