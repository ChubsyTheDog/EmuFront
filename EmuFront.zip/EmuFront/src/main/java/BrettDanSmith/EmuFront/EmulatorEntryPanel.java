package BrettDanSmith.EmuFront;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SpringLayout;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

public class EmulatorEntryPanel extends JPanel {
	private static final long serialVersionUID = -1304495541333045419L;
	private Dimension size = new Dimension(256, 256);
	private BufferedImage image;

	/**
	 * Create the panel.
	 * 
	 * @param data
	 */
	public EmulatorEntryPanel(ConsoleData data) {
		setPreferredSize(size);
		setSize(size);
		setMinimumSize(size);
		setMaximumSize(size);
		SpringLayout springLayout = new SpringLayout();
		setLayout(springLayout);

		JLabel lblNewLabel = new JLabel(data.consoleTitle);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel, 0, SpringLayout.NORTH, this);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel, 0, SpringLayout.WEST, this);
		springLayout.putConstraint(SpringLayout.SOUTH, lblNewLabel, 32, SpringLayout.NORTH, this);
		springLayout.putConstraint(SpringLayout.EAST, lblNewLabel, 0, SpringLayout.EAST, this);
		add(lblNewLabel);
		try {
			image = ImageIO.read(new File(data.consoleDirectory, data.consoleIcon));
		} catch (Exception e) {
		}

		JPanel panel = new JPanel() {
			@Override
			public void paint(Graphics g) {
				super.paint(g);
				if (image != null) {
					g.drawImage(image, (getWidth() - 192) / 2, (getHeight() - 192) / 2, 192, 192, null);
				}
			}
		};
		springLayout.putConstraint(SpringLayout.NORTH, panel, 0, SpringLayout.SOUTH, lblNewLabel);
		springLayout.putConstraint(SpringLayout.WEST, panel, 8, SpringLayout.WEST, this);
		springLayout.putConstraint(SpringLayout.SOUTH, panel, -32, SpringLayout.SOUTH, this);
		springLayout.putConstraint(SpringLayout.EAST, panel, -8, SpringLayout.EAST, this);
		add(panel);

		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		springLayout.putConstraint(SpringLayout.NORTH, btnNewButton, -32, SpringLayout.SOUTH, this);
		springLayout.putConstraint(SpringLayout.WEST, btnNewButton, -32, SpringLayout.EAST, this);
		springLayout.putConstraint(SpringLayout.SOUTH, btnNewButton, 0, SpringLayout.SOUTH, this);
		springLayout.putConstraint(SpringLayout.EAST, btnNewButton, 0, SpringLayout.EAST, lblNewLabel);
		add(btnNewButton);

		setBorder(new LineBorder(Color.LIGHT_GRAY));
	}
}
