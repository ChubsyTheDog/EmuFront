package BrettDanSmith.EmuFront;

import java.io.File;

public class ConsoleData {

	public File consoleFile;
	public File consoleDirectory;
	public String consoleName;
	public String consoleTitle;
	public String consoleIcon;
	public String starting_args;

}
