package BrettDanSmith.EmuFront;

public class App {
	public static void main(String[] args) {
		EmuFrontCore.preInit(args);
		EmuFrontConfig config = new EmuFrontConfig("config.cfg", args);
		config.load();
		EmuFrontCore core = new EmuFrontCore(config);
		core.initialise();
		EmuFrontWindow window = new EmuFrontWindow(config, core);
		window.showWindow();
	}
}
